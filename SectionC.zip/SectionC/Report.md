#Report

The program works accordingly 
Values to be used must be between 0 and 999999999999999
The minimum value is -9 223 372 036 854 775 808, the maximum value is 9 223 372 036 854 775 807 for the long type
