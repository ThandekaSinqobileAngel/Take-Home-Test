package mytest;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import static org.junit.Assert.*;

class SayTheNumberSectionCTest {

	@Test
	void testSayNumber() {
		
		SayTheNumberSectionC saynum = new SayTheNumberSectionC();
		String expected = "Ninety Trillion, Three Hundred Seventy Six Billion, Ten Thousand, Twelve.";
		String actual = saynum.sayNumber(999999999999999L);
		
		assertEqual(expected, actual);
	}

	private void assertEqual(String expected, String actual) {
		
		
	}

}
