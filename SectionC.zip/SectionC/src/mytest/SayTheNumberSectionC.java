package mytest;

public class SayTheNumberSectionC {
	// Numbers from which we will retrieve our words.
    private static String[] less_than_twenty = {"","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen","Seventeen","Eighteen","Nineteen"};

    private static String[] tens = {"","","Twenty","Thirty","Forty","Fifty","Sixty","Seventy","Eighty","Ninety"};

    private static String[] chunks = {"","Thousand","Million","Billion","Trillion"};

    // The function takes the numerical value and breaks it into parts with 3 digits each.
    // Then it passes it to next function coupled with it that will build the string for it.
    public static String sayNumber(Long num) {
        if(num==0) return "Zero.";

        String ans = new String();

        int index=0;
        while(num>0){
            if(num%1000!=0){
                ans = convertThreeDigit(num%1000) + chunks[index]+", "+ans;
            }
            index++;
            num/=1000;
        }

        // For our punctuation, we will use substring and trim methods.
        return ans.trim().substring(0,ans.length()-3)+".";

    }

    // This recursive function receives the 3 digits number and builds the string.
    private static String convertThreeDigit(long num){
        if(num==0)return "";
        if(num<20) return less_than_twenty[(int)num]+" ";

        else if(num<100) return tens[(int)num/10] + " " + convertThreeDigit(num%10);

        else return less_than_twenty[(int)num/100] + " "+"Hundred"+" "+convertThreeDigit(num%100);
    }

    // Main function to test inputs.
    public static void main(String[] args) {
        long n1 = 0L;
        long n2 = 11L;
        long n3 = 1043283L;
        long n4 = 90376000010012L;
        System.out.println(sayNumber(n1)+"\n"+sayNumber(n2)+"\n"+sayNumber(n3)+"\n"+sayNumber(n4));
    }
}



	
	
	    