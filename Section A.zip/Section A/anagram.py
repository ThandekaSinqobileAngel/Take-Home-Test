#!/usr/bin/env python
# coding: utf-8

# In[34]:


# This is how the program should look like.
class Solution:
    
  # iniialise the list  
  strs = ["eat","tea","tan","ate","nat","bat"]
    
  # Create a function with two parameters  
  def groupAnagrams(self, strs):
        
      # initialise an empty dictionary  
      result = {}
        
      # iterate over the list to group all anagrams  
      for i in strs:
            
         # sorts the list of items in ascending order 
         x = "".join(sorted(i))
         
         # checking the string in dictionary
         if x in result:
            
            # adding the string to the group anagrams 
            result[x].append(i)
         else:
            
            # initializing a list with current string
            result[x] = [i]  
      
      # returning the list of anagrams
      return list(result.values())

# calling the class with function used to groups anagrams 
ob1 = Solution()

# printing the values of the dict (anagram groups)
print(ob1.groupAnagrams(["eat", "tea", "tan", "ate", "nat", "bat"]))

